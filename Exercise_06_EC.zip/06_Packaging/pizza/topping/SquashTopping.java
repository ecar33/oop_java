package pizza.topping;
public class SquashTopping extends VeggieTopping {
    @Override
    public String toString() {
        return "Squash Topping";
    } 
}
