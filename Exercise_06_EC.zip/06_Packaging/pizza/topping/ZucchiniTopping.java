package pizza.topping;
public class ZucchiniTopping extends VeggieTopping {
    @Override
    public String toString() {
        return "Zucchini Topping";
    }
}
