package pizza.topping;
public class MozzarellaTopping extends CheeseTopping {
    @Override
    public String toString() {
        return "Mozzarella Topping";
    } 
}
