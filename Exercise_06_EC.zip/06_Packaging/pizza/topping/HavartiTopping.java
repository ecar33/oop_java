package pizza.topping;
public class HavartiTopping extends CheeseTopping {
    @Override
    public String toString() {
        return "Havarti Topping";
    } 
}
