package pizza.topping;
public class ProvoloneTopping extends CheeseTopping {
    @Override
    public String toString() {
        return "Provolone Topping";
    } 
}
