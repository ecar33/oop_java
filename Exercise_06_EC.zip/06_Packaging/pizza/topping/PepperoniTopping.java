package pizza.topping;
public class PepperoniTopping extends MeatTopping {
    @Override
    public String toString() {
        return "Pepperoni";
    }
}