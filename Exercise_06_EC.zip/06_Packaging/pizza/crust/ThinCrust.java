package pizza.crust;
import pizza.PizzaCrust;

public class ThinCrust extends PizzaCrust {
    @Override
    public String toString() {
        return "Thin Crust";
    }
}
