package pizza.topping;
public interface MenuItem {
    public Double getPrice();
}