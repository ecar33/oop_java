package pizza.crust;
import pizza.PizzaCrust;

public class ThickCrust extends PizzaCrust {
    @Override
    public String toString() {
        return "Thick Crust";
    }
}
