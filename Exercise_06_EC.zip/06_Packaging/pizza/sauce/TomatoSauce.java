package pizza.sauce;
public class TomatoSauce extends PizzaSauce {
    @Override
    public String toString() {
        return "Tomato Sauce";
    }
}
